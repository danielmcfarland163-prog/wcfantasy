# World Cup Fantasy — Changelog

---

## Unreleased

### League Leaderboards — realtime, dual-mode standings, sort/filter (2026-06-06)

- **Live standings, no refresh.** `LeagueClient` now hydrates from the server then opens a Supabase realtime subscription to `league_scores` (filtered by `league_id`). When the scoring engine writes new totals, the board re-fetches and re-ranks in place; changed rows briefly pulse (`wc-flash`/`wc-flash-me`, reduced-motion aware) and a green **LIVE** chip shows the channel is connected. Same channel pattern as `LeagueChat`.
- **Dual-mode tabs** ("My Picks" / "Bracket", plus "Combined" for combined leagues). Each tab ranks independently; ranks are computed client-side (competition ranking with ties) so they stay correct through live updates. Tabs are derived from `game_mode` (single-mode leagues show one view).
- **Sort & filter.** Sort by Rank / Pts / Name and a name search box. The podium (top 3) shows in the default rank view; any sort/filter collapses to the full sortable table. Empty-state when a search matches no one.
- **KPI column per mode.** Picks → exact scores (+ correct results); Bracket → correct predictions; Combined → P·B split. Rank-change chips now render **▲ / ▼ / —** (flat included) on both the podium and the table.
- **Members & commissioner.** New Members roster (avatars, join date, 👑 Commissioner + YOU badges) sourced from a widened `page.tsx` fetch (`profiles` + `joined_at`), plus a commissioner-only invite/share card.
- **Schema:** migration `add_bracket_correct_to_league_scores` adds `league_scores.bracket_correct` (backfilled from `global_scores`); `scoreBrackets` now persists it. Mobile table scrolls horizontally below 320px. Recorded at `docs/deployment/2026-06-06-league-scores-bracket-correct.sql`.

### Bracket — spec scoring, dual-mode standings & lock UX (2026-06-06)

- **Corrected bracket scoring to match GDD §2.2.** The engine was awarding `2/1/1/2/4/6/8/15` (group 1st/2nd, 3rd, R32, R16, QF, SF, Final). It now awards the spec values **2 / 2 / 2 / 3 / 5 / 8 / 13 / 21** (231 max). Point values now live in a single source of truth, `lib/bracket-scoring.ts`, consumed by the server engine **and** the UI so they can never drift again.
- **Fixed the broken league Bracket leaderboard.** `league_scores` was missing the `picks_points` / `bracket_points` (+ rank) columns the UI already read, and `scoreBrackets` was writing bracket points into `total_points`, **clobbering each member's My Picks score**. Migration `dual_mode_league_scores` adds the per-mode columns and a dual-mode `recalculate_league_rankings()`; the engine now writes `bracket_points` only and the function recomputes `total_points = picks + bracket` and both rank columns. My Picks scores are preserved.
- `lib/score-utils.ts`: `scoreBrackets` rewired to `scoreBracketEntry()`; `scorePicks` now also writes `picks_points` to `league_scores`. Both remain idempotent (re-runs recompute identical totals).
- **Lock UX:** new `LockCountdown` component — a calm lock-date chip that escalates to a prominent amber **live HH:MM:SS countdown within 24h** of the June 11 15:00 UTC lock. Added a **Submit / "Lock in my bracket"** confirmation in the Summary (and a *R