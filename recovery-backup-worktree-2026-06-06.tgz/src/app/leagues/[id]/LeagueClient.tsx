'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase'
import { formatRelativeTime } from '@/lib/utils'
import LeagueChat from '@/components/LeagueChat'
import CopyInviteButton from '@/components/CopyInviteButton'
import BracketReviewer from '@/components/BracketReviewer'
import LiveDot from '@/components/ui/LiveDot'

type GameMode = 'picks' | 'bracket' | 'both' | 'combined'
type StandingsTab = 'picks' | 'bracket' | 'combined'
type SortKey = 'rank' | 'points' | 'name'

const MODE_META: Record<GameMode, { icon: string; label: string }> = {
  picks:    { icon: '⚽', label: 'Match Picks' },
  bracket:  { icon: '🗂',  label: 'Bracket' },
  both:     { icon: '✦',  label: 'Both Modes' },
  combined: { icon: '⚡', label: 'Combined' },
}

const TAB_META: Record<StandingsTab, { icon: string; label: string }> = {
  picks:    { icon: '⚽', label: 'My Picks' },
  bracket:  { icon: '🗂',  label: 'Bracket' },
  combined: { icon: '⚡', label: 'Combined' },
}

const TABS_FOR_MODE: Record<GameMode, StandingsTab[]> = {
  picks:    ['picks'],
  bracket:  ['bracket'],
  both:     ['picks', 'bracket'],
  combined: ['picks', 'bracket', 'combined'],
}

function initials(name: string) {
  return name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()
}

const AVATAR_COLORS = ['#2f6fe0','#1f9d5a','#e03c2c','#c98a1a','#7c3aed','#0891b2','#db2777','#059669']
function avatarColor(str: string) {
  let h = 0; for (const c of str) h = (h * 31 + c.charCodeAt(0)) & 0xffff
  return AVATAR_COLORS[h % AVATAR_COLORS.length]
}

function Avatar({ name, size = 36 }: { name: string; size?: number }) {
  const color = avatarColor(name)
  return (
    <div style={{ width: size, height: size, borderRadius: '50%', background: color, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
      <span style={{ fontFamily: 'var(--f-cond)', fontWeight: 800, fontSize: size * 0.38, color: '#fff', lineHeight: 1 }}>{initials(name)}</span>
    </div>
  )
}

/** Rank trend chip: ▲ up (green) · ▼ down (red) · — flat (muted). */
function RankChange({ change }: { change: number }) {
  if (!change) {
    return <span style={{ fontFamily: 'var(--f-mono)', fontSize: 10, color: 'var(--ink-3)' }}>—</span>
  }
  const up = change > 0
  return (
    <span style={{ fontFamily: 'var(--f-mono)', fontSize: 10, fontWeight: 700, color: up ? 'var(--win)' : 'var(--live)', display: 'inline-flex', alignItems: 'center', gap: 1 }}>
      {up ? '▲' : '▼'} {Math.abs(change)}
    </span>
  )
}

interface Score {
  user_id: string
  total_points: number
  picks_points?: number
  bracket_points?: number
  picks_rank?: number
  bracket_rank?: number
  picks_rank_change?: number
  bracket_rank_change?: number
  rank_change?: number
  picks_made?: number
  exact_scores?: number
  correct_results?: number
  bracket_correct?: number
  profile?: { username: string; display_name?: string }
}

interface Member {
  user_id: string
  joined_at: string
  profile?: { username: string; display_name?: string; avatar_url?: string | null }
}

interface TournamentResults {
  group_results: Record<string, { first: string; second: string; third: string }>
  third_quals: string[]
  r32_results: (string | null)[]
  r16_results: (string | null)[]
  qf_results:  (string | null)[]
  sf_results:  (string | null)[]
  final_result: string | null
}

interface LeagueClientProps {
  league: { id: string; name: string; description?: string; invite_code: string; game_mode?: GameMode; commissioner_id: string }
  scores: Score[]
  members: Member[]
  bracketEntries: any[]
  currentUserId: string
  currentProfile: { username: string; display_name?: string } | null
  inviteUrl: string
  tournamentResults?: TournamentResults | null
}

function nameOf(s: { profile?: { username: string; display_name?: string } }) {
  return s.profile?.display_name ?? s.profile?.username ?? 'Player'
}

export default function LeagueClient({ league, scores: initialScores, members, bracketEntries, currentUserId, currentProfile, inviteUrl, tournamentResults }: LeagueClientProps) {
  const mode: GameMode = league.game_mode ?? 'both'
  const modeMeta = MODE_META[mode]
  const tabs = TABS_FOR_MODE[mode] ?? ['picks']
  const showTabs = tabs.length > 1
  const isCommissioner = currentUserId === league.commissioner_id

  const defaultTab: StandingsTab = mode === 'bracket' ? 'bracket' : mode === 'combined' ? 'combined' : 'picks'
  const [activeTab, setActiveTab] = useState<StandingsTab>(defaultTab)
  const [sortKey, setSortKey] = useState<SortKey>('rank')
  const [query, setQuery] = useState('')

  // ── Live standings (hydrated from server, kept fresh via realtime) ──────────
  const supabase = useMemo(() => createClient(), [])
  const [scores, setScores] = useState<Score[]>(initialScores)
  const [live, setLive] = useState(false)
  const [flashing, setFlashing] = useState<Set<string>>(new Set())
  const flashTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const snapshot = (rows: Score[]) =>
    Object.fromEntries(rows.map(r => [r.user_id, { picks: r.picks_points ?? 0, bracket: r.bracket_points ?? 0, total: r.total_points ?? 0 }]))
  const prevPointsRef = useRef<Record<string, { picks: number; bracket: number; total: number }>>(snapshot(initialScores))

  useEffect(() => {
    const channel = supabase
      .channel(`league-scores-${league.id}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'league_scores', filter: `league_id=eq.${league.id}` },
        async () => {
          const { data } = await supabase
            .from('league_scores')
            .select('*, profile:profiles(username, display_name)')
            .eq('league_id', league.id)
            .order('total_points', { ascending: false })
          if (!data) return
          const rows = data as Score[]
          const prev = prevPointsRef.current
          const changed = new Set<string>()
          for (const r of rows) {
            const p = prev[r.user_id]
            if (p && (p.picks !== (r.picks_points ?? 0) || p.bracket !== (r.bracket_points ?? 0) || p.total !== (r.total_points ?? 0))) {
              changed.add(r.user_id)
            }
          }
          prevPointsRef.current = snapshot(rows)
          setScores(rows)
          if (changed.size) {
            setFlashing(changed)
            if (flashTimer.current) clearTimeout(flashTimer.current)
            flashTimer.current = setTimeout(() => setFlashing(new Set()), 1500)
          }
        },
      )
      .subscribe((status) => setLive(status === 'SUBSCRIBED'))

    return () => {
      if (flashTimer.current) clearTimeout(flashTimer.current)
      supabase.removeChannel(channel)
    }
  }, [league.id, supabase])

  // ── Per-tab accessors ───────────────────────────────────────────────────────
  function getPoints(s: Score): number {
    if (activeTab === 'bracket') return s.bracket_points ?? 0
    if (activeTab === 'combined') return (s.picks_points ?? 0) + (s.bracket_points ?? 0)
    return s.picks_points ?? s.total_points ?? 0
  }
  function getRankChange(s: Score): number {
    if (activeTab === 'bracket') return s.bracket_rank_change ?? 0
    if (activeTab === 'combined') return 0
    return s.picks_rank_change ?? s.rank_change ?? 0
  }
  function getKpi(s: Score): { value: string | number; label: string; sub?: string } {
    if (activeTab === 'bracket') return { value: s.bracket_correct ?? 0, label: 'correct' }
    if (activeTab === 'combined') return { value: `${s.picks_points ?? 0}·${s.bracket_points ?? 0}`, label: 'P · B' }
    return { value: s.exact_scores ?? 0, label: 'exact', sub: `${s.correct_results ?? 0} correct` }
  }
  const kpiHeader = activeTab === 'bracket' ? 'CORRECT' : activeTab === 'combined' ? 'P · B' : 'EXACT'

  // ── Ranking (computed client-side so it stays correct through live updates) ──
  const ranked = useMemo(() => {
    const rows = scores.map(s => ({ s, pts: getPoints(s), name: nameOf(s) }))
    const byPts = [...rows].sort((a, b) => b.pts - a.pts)
    const rankMap = new Map<string, number>()
    let lastPts: number | null = null
    let lastRank = 0
    byPts.forEach((row, i) => {
      const rank = lastPts !== null && row.pts === lastPts ? lastRank : i + 1
      rankMap.set(row.s.user_id, rank)
      lastPts = row.pts
      lastRank = rank
    })
    return { rows, byPts, rankMap }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scores, activeTab])

  const q = query.trim().toLowerCase()
  const isDefaultView = sortKey === 'rank' && !q

  const filtered = q ? ranked.rows.filter(r => r.name.toLowerCase().includes(q)) : ranked.rows
  const sorted = [...filtered].sort((a, b) => {
    if (sortKey === 'name') return a.name.localeCompare(b.name)
    if (sortKey === 'points') return b.pts - a.pts
    return (ranked.rankMap.get(a.s.user_id) ?? 0) - (ranked.rankMap.get(b.s.user_id) ?? 0)
  })

  const podium = isDefaultView ? sorted.slice(0, 3) : []
  const tableRows = isDefaultView ? sorted.slice(3) : sorted
  const hasScores = scores.length > 0

  const sortOptions: { key: SortKey; label: string }[] = [
    { key: 'rank', label: 'Rank' },
    { key: 'points', label: 'Pts' },
    { key: 'name', label: 'Name' },
  ]

  return (
    <div style={{ paddingBottom: 40, background: 'var(--bg)', minHeight: '100svh' }}>

      {/* ── HERO ─────────────────────────────────────── */}
      <div style={{
        background: 'linear-gradient(145deg, var(--accent) 0%, color-mix(in srgb, var(--accent) 55%, #0a0d1a) 100%)',
        padding: '16px 20px 28px',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', top: -40, right: -40, width: 180, height: 180, borderRadius: '50%', background: 'rgba(255,255,255,0.05)', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', bottom: -60, left: -20, width: 140, height: 140, borderRadius: '50%', background: 'rgba(255,255,255,0.04)', pointerEvents: 'none' }} />

        <Link href="/leagues" style={{ fontFamily: 'var(--f-mono)', fontSize: 10, letterSpacing: 0.5, color: 'rgba(255,255,255,0.6)', textDecoration: 'none', display: 'inline-block', marginBottom: 16 }}>
          ← Leagues
        </Link>

        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '3px 10px', borderRadius: 20, background: 'rgba(255,255,255,0.15)', marginBottom: 10 }}>
              <span style={{ fontSize: 12 }}>{modeMeta.icon}</span>
              <span style={{ fontFamily: 'var(--f-mono)', fontSize: 9, fontWeight: 700, letterSpacing: '1px', color: 'rgba(255,255,255,0.9)', textTransform: 'uppercase' }}>{modeMeta.label}</span>
            </div>
            <h1 style={{ fontFamily: 'var(--f-cond)', fontWeight: 800, fontSize: 28, color: '#fff', lineHeight: 1.1, margin: 0, wordBreak: 'break-word' }}>{league.name}</h1>
            {league.description && (
              <p style={{ fontFamily: 'var(--f-body)', fontSize: 13, color: 'rgba(255,255,255,0.65)', marginTop: 6, marginBottom: 0 }}>{league.description}</p>
            )}
            <div style={{ fontFamily: 'var(--f-mono)', fontSize: 10, color: 'rgba(255,255,255,0.5)', marginTop: 8 }}>
              {members.length} member{members.length !== 1 ? 's' : ''}
              {isCommissioner && <span style={{ marginLeft: 8, color: 'rgba(255,255,255,0.7)' }}>· 👑 You run this league</span>}
            </div>
          </div>
        </div>

        {/* Invite code strip */}
        <div style={{ marginTop: 20, padding: '12px 14px', background: 'rgba(0,0,0,0.25)', borderRadius: 14, display: 'flex', alignItems: 'center', gap: 12, backdropFilter: 'blur(8px)' }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'var(--f-mono)', fontSize: 9, letterSpacing: '1px', color: 'rgba(255,255,255,0.45)', marginBottom: 3 }}>INVITE CODE</div>
            <div style={{ fontFamily: 'var(--f-mono)', fontSize: 20, fontWeight: 700, color: '#fff', letterSpacing: 4 }}>{league.invite_code}</div>
          </div>
          <CopyInviteButton inviteUrl={inviteUrl} />
        </div>
      </div>

      {/* ── STANDINGS ────────────────────────────────── */}
      <div style={{ padding: '24px 20px 0' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14, gap: 10 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontFamily: 'var(--f-mono)', fontSize: 10, fontWeight: 700, letterSpacing: '1.5px', color: 'var(--ink-3)', textTransform: 'uppercase' }}>Standings</span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '2px 7px', borderRadius: 20, background: live ? 'color-mix(in srgb, var(--win) 12%, transparent)' : 'var(--surface-2)', border: `1px solid ${live ? 'color-mix(in srgb, var(--win) 30%, transparent)' : 'var(--line)'}` }}>
              <LiveDot size={6} color={live ? 'var(--win)' : 'var(--ink-3)'} />
              <span style={{ fontFamily: 'var(--f-mono)', fontSize: 8, fontWeight: 700, letterSpacing: '0.6px', color: live ? 'var(--win)' : 'var(--ink-3)' }}>{live ? 'LIVE' : 'SYNC'}</span>
            </span>
          </div>

          {showTabs && (
            <div style={{ display: 'flex', background: 'var(--surface-2)', borderRadius: 10, padding: 3, border: '1px solid var(--line)' }}>
              {tabs.map(tab => (
                <button key={tab} onClick={() => setActiveTab(tab)}
                  style={{ padding: '5px 12px', borderRadius: 7, border: 'none', cursor: 'pointer', fontFamily: 'var(--f-mono)', fontSize: 10, fontWeight: 700, letterSpacing: '0.5px', transition: 'all .15s', background: activeTab === ta